import React from "react"
import './event-graph.css';

const LeftBar = (props) => {
  return (
    <div className='LeftBar' display ={"flex"}>
      <p>Home</p>
      <p>EventGraph</p>
    </div>
  )
};

export default LeftBar;
